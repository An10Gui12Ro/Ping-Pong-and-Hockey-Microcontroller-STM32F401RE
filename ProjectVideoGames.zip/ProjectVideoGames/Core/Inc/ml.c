/*
 * lcd.c
 *
 *  Created on: Sep 25, 2024
 *      Author: AGpar
 */

#include <ml.h>
#include <stdlib.h>

uint8_t min, max, x;
uint8_t points_player1 = 0, points_player2 = 0, p1 = 1, p2 = 0;

void LED_Matrices_init(void)
{
	  GPIO_InitTypeDef GPIO_InitStruct = {0};
	/* USER CODE BEGIN MX_GPIO_Init_1 */
	/* USER CODE END MX_GPIO_Init_1 */

	  /* GPIO Ports Clock Enable */
	  __HAL_RCC_GPIOC_CLK_ENABLE();
	  __HAL_RCC_GPIOA_CLK_ENABLE();
	  __HAL_RCC_GPIOB_CLK_ENABLE();
	  __HAL_RCC_GPIOD_CLK_ENABLE();

	  /*Configure GPIO pin Output Level */
	  HAL_GPIO_WritePin(GPIOC, ML1_F5_Pin|ML1_F4_Pin|ML1_F6_Pin|ML1_F7_Pin
							  |ML2_F2_Pin|ML2_F1_Pin|ML2_F0_Pin|ML2_C3_Pin
							  |ML1_C0_Pin|ML1_C6_Pin|ML1_C1_Pin, GPIO_PIN_RESET);

	  /*Configure GPIO pin Output Level */
	  HAL_GPIO_WritePin(GPIOA, ML1_F0_Pin|ML1_F1_Pin|ML1_F2_Pin|ML2_C6_Pin
							  |ML2_C7_Pin|ML1_C2_Pin|ML2_F4_Pin|ML2_F3_Pin
							  |ML1_C4_Pin, GPIO_PIN_RESET);

	  /*Configure GPIO pin Output Level */
	  HAL_GPIO_WritePin(GPIOB, ML1_F3_Pin|ML2_F7_Pin|ML2_F6_Pin|ML1_C3_Pin
							  |ML2_F5_Pin|ML2_C2_Pin|ML2_C1_Pin|ML2_C0_Pin
							  |ML1_C5_Pin|ML2_C4_Pin|ML2_C5_Pin, GPIO_PIN_RESET);

	  /*Configure GPIO pin Output Level */
	  HAL_GPIO_WritePin(ML1_C7_GPIO_Port, ML1_C7_Pin, GPIO_PIN_RESET);

	  /*Configure GPIO pins : ML1_F5_Pin ML1_F4_Pin ML1_F6_Pin ML1_F7_Pin
							   ML2_F2_Pin ML2_F1_Pin ML2_F0_Pin ML2_C3_Pin
							   ML1_C0_Pin ML1_C6_Pin ML1_C1_Pin */
	  GPIO_InitStruct.Pin = ML1_F5_Pin|ML1_F4_Pin|ML1_F6_Pin|ML1_F7_Pin
							  |ML2_F2_Pin|ML2_F1_Pin|ML2_F0_Pin|ML2_C3_Pin
							  |ML1_C0_Pin|ML1_C6_Pin|ML1_C1_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	  /*Configure GPIO pins : ML1_F0_Pin ML1_F1_Pin ML1_F2_Pin ML2_C6_Pin
							   ML2_C7_Pin ML1_C2_Pin ML2_F4_Pin ML2_F3_Pin
							   ML1_C4_Pin */
	  GPIO_InitStruct.Pin = ML1_F0_Pin|ML1_F1_Pin|ML1_F2_Pin|ML2_C6_Pin
							  |ML2_C7_Pin|ML1_C2_Pin|ML2_F4_Pin|ML2_F3_Pin
							  |ML1_C4_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	  /*Configure GPIO pins : ML1_F3_Pin ML2_F7_Pin ML2_F6_Pin ML1_C3_Pin
							   ML2_F5_Pin ML2_C2_Pin ML2_C1_Pin ML2_C0_Pin
							   ML1_C5_Pin ML2_C4_Pin ML2_C5_Pin */
	  GPIO_InitStruct.Pin = ML1_F3_Pin|ML2_F7_Pin|ML2_F6_Pin|ML1_C3_Pin
							  |ML2_F5_Pin|ML2_C2_Pin|ML2_C1_Pin|ML2_C0_Pin
							  |ML1_C5_Pin|ML2_C4_Pin|ML2_C5_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	  /*Configure GPIO pin : ML1_C7_Pin */
	  GPIO_InitStruct.Pin = ML1_C7_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(ML1_C7_GPIO_Port, &GPIO_InitStruct);

	/* USER CODE BEGIN MX_GPIO_Init_2 */
	/* USER CODE END MX_GPIO_Init_2 */
}

//WRITE NUMBERS
void write_0(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b01111110);
		ping_pong_open_col_ML1(0b10111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111111);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10000001);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10000001);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111111);
		ping_pong_open_col_ML1(0b11111011);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b01111110);
		ping_pong_open_col_ML1(0b11111101);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

	}
	else{
		ping_pong_open_row_ML2(0b01111110);
		ping_pong_open_col_ML2(0b10111111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111111);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10000001);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10000001);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111111);
		ping_pong_open_col_ML2(0b11111011);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b01111110);
		ping_pong_open_col_ML2(0b11111101);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);
	}
}
void write_1(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b01000000);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111111);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111111);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);
	}
	else{
		ping_pong_open_row_ML2(0b01000000);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111111);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111111);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);
	}
}
void write_2(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b01000110);
		ping_pong_open_col_ML1(0b10111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11001110);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10011010);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10010010);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11110010);
		ping_pong_open_col_ML1(0b11111011);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b01110010);
		ping_pong_open_col_ML1(0b11111101);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);
	}
	else{
		ping_pong_open_row_ML2(0b01000110);
		ping_pong_open_col_ML2(0b10111111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11001110);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10011010);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10010010);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11110010);
		ping_pong_open_col_ML2(0b11111011);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b01110010);
		ping_pong_open_col_ML2(0b11111101);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);
	}
}
void write_3(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b01000100);
		ping_pong_open_col_ML1(0b10111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11000110);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10010010);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10010010);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111110);
		ping_pong_open_col_ML1(0b11111011);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b01101100);
		ping_pong_open_col_ML1(0b11111101);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

	}
	else{
		ping_pong_open_row_ML2(0b01000100);
		ping_pong_open_col_ML2(0b10111111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11000110);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10010010);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10010010);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111110);
		ping_pong_open_col_ML2(0b11111011);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b01101100);
		ping_pong_open_col_ML2(0b11111101);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);
	}
}
void write_4(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b00011000);
		ping_pong_open_col_ML1(0b10111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b00111000);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b01101000);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11001000);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111110);
		ping_pong_open_col_ML1(0b11111011);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111110);
		ping_pong_open_col_ML1(0b11111101);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

	}
	else{
		ping_pong_open_row_ML2(0b00011000);
		ping_pong_open_col_ML2(0b10111111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b00111000);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b01101000);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11001000);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111110);
		ping_pong_open_col_ML2(0b11111011);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111110);
		ping_pong_open_col_ML2(0b11111101);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

	}
}
void write_5(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b11100100);
		ping_pong_open_col_ML1(0b10111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11100110);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10100010);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10100010);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10111110);
		ping_pong_open_col_ML1(0b11111011);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10011100);
		ping_pong_open_col_ML1(0b11111101);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

	}
	else{
		ping_pong_open_row_ML2(0b11100100);
		ping_pong_open_col_ML2(0b10111111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11100110);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10100010);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10100010);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10111110);
		ping_pong_open_col_ML2(0b11111011);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10011100);
		ping_pong_open_col_ML2(0b11111101);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);
	}
}
void write_6(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b01111100);
		ping_pong_open_col_ML1(0b10111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111110);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10010010);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10010010);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11011110);
		ping_pong_open_col_ML1(0b11111011);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b01001100);
		ping_pong_open_col_ML1(0b11111101);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);
	}
	else{
		ping_pong_open_row_ML2(0b01111100);
		ping_pong_open_col_ML2(0b10111111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111110);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10010010);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10010010);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11011110);
		ping_pong_open_col_ML2(0b11111011);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b01001100);
		ping_pong_open_col_ML2(0b11111101);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);
	}
}
void write_7(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b10000000);
		ping_pong_open_col_ML1(0b10111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10000000);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10001110);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10011110);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11110000);
		ping_pong_open_col_ML1(0b11111011);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11100000);
		ping_pong_open_col_ML1(0b11111101);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);
	}
	else{
		ping_pong_open_row_ML2(0b10000000);
		ping_pong_open_col_ML2(0b10111111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10000000);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10001110);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10011110);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11110000);
		ping_pong_open_col_ML2(0b11111011);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11100000);
		ping_pong_open_col_ML2(0b11111101);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);
	}
}
void write_8(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b01101100);
		ping_pong_open_col_ML1(0b10111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111110);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10010010);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10010010);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111110);
		ping_pong_open_col_ML1(0b11111011);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b01101100);
		ping_pong_open_col_ML1(0b11111101);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);
	}
	else{
		ping_pong_open_row_ML2(0b01101100);
		ping_pong_open_col_ML2(0b10111111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111110);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10010010);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10010010);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111110);
		ping_pong_open_col_ML2(0b11111011);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b01101100);
		ping_pong_open_col_ML2(0b11111101);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);
	}
}
void write_9(uint8_t matrix){
	if(matrix == 1){
		ping_pong_open_row_ML1(0b01100100);
		ping_pong_open_col_ML1(0b10111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11110110);
		ping_pong_open_col_ML1(0b11011111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10010010);
		ping_pong_open_col_ML1(0b11101111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b10010010);
		ping_pong_open_col_ML1(0b11110111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b11111110);
		ping_pong_open_col_ML1(0b11111011);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);

		ping_pong_open_row_ML1(0b01111100);
		ping_pong_open_col_ML1(0b11111101);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_col_ML1(0b11111111);
	}
	else{
		ping_pong_open_row_ML2(0b01100100);
		ping_pong_open_col_ML2(0b10111111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11110110);
		ping_pong_open_col_ML2(0b11011111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10010010);
		ping_pong_open_col_ML2(0b11101111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b10010010);
		ping_pong_open_col_ML2(0b11110111);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b11111110);
		ping_pong_open_col_ML2(0b11111011);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);

		ping_pong_open_row_ML2(0b01111100);
		ping_pong_open_col_ML2(0b11111101);
		ping_pong_open_row_ML2(0b00000000);
		ping_pong_open_col_ML2(0b11111111);
	}
}
//WRITE NUMBERS

//PING-PONG
void ping_pong_open_col_ML1(uint8_t bits){
	uint8_t bit;

	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C7_GPIO_Port, ML1_C7_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C6_GPIO_Port, ML1_C6_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C5_GPIO_Port, ML1_C5_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C4_GPIO_Port, ML1_C4_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C3_GPIO_Port, ML1_C3_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C2_GPIO_Port, ML1_C2_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C1_GPIO_Port, ML1_C1_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C0_GPIO_Port, ML1_C0_Pin, bit);
}

void ping_pong_open_row_ML1(uint8_t bits){
	uint8_t bit;

	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F7_GPIO_Port, ML1_F7_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F6_GPIO_Port, ML1_F6_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F5_GPIO_Port, ML1_F5_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F4_GPIO_Port, ML1_F4_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F3_GPIO_Port, ML1_F3_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F2_GPIO_Port, ML1_F2_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F1_GPIO_Port, ML1_F1_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F0_GPIO_Port, ML1_F0_Pin, bit);
}

void ping_pong_open_col_ML2(uint8_t bits){
	uint8_t bit;

	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C7_GPIO_Port, ML2_C7_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C6_GPIO_Port, ML2_C6_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C5_GPIO_Port, ML2_C5_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C4_GPIO_Port, ML2_C4_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C3_GPIO_Port, ML2_C3_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C2_GPIO_Port, ML2_C2_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C1_GPIO_Port, ML2_C1_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C0_GPIO_Port, ML2_C0_Pin, bit);
}

void ping_pong_open_row_ML2(uint8_t bits){
	uint8_t bit;

	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F7_GPIO_Port, ML2_F7_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F6_GPIO_Port, ML2_F6_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F5_GPIO_Port, ML2_F5_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F4_GPIO_Port, ML2_F4_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F3_GPIO_Port, ML2_F3_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F2_GPIO_Port, ML2_F2_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F1_GPIO_Port, ML2_F1_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F0_GPIO_Port, ML2_F0_Pin, bit);
}

void ping_pong_ball_going_down_right_left(uint8_t *ball_row, uint8_t *ball_matrix, uint8_t *ball_col, uint8_t *direction, uint8_t *flag){
	/*creo que la condicion de flag debe ir aqui porque no quiero que prenda ese led porque si no me apagará
	  los de la raqueta*/

	//PRENDE EL LED
	if(*ball_matrix == 1)
		ping_pong_open_row_ML1(*ball_row);
	else if(*ball_matrix == 2)
		ping_pong_open_row_ML2(*ball_row);

	if(*ball_col == 0b01111111 && *ball_matrix == 2){//SI LLEGA A TOPE DE LA MATRIZ 2
		//NUNCA VA A ENTRAR EN ESTA CONDICION PORQUE NUNCA VA ASER '0b00000001' EN EL TOPE DE LA
		// MATRIZ 2 YA QUE AL MOMENTO EN QUE LE DOY CON LA RAQUETA EN ALGUNA ESQUINA
		// DA COMO QUE LA VUELTA Y POR ESO NO REGRESA POR DONDE VINO SI NO UN LED ARRIBA O ABAJO

		/*if(*ball_row == 0b00000001){//SI LLEGA A TOPE DE LA MATRIZ 2 Y ADEMÁS LLEGA AL BOTTOM
			*ball_row <<= 1;
			*direction = 'u';
		}*/
		if(*ball_row == 0b00000010){//SI LLEGA A TOPE DE LA MATRIZ 2 Y ADEMÁS LLEGA 1 ANTES DEL BOTTOM
		    srand(HAL_GetTick());
		    min = 1, max = 6;
		    x = rand() % (max - min + 1) + min;
		    while(x--){
		    	*ball_row <<= 1;
		    }
		    min= 1, max = 2;
		    x = rand() % (max - min + 1) + min;
		    if(x == 1) //NO PASA NADA SI LA PELOTA ESTA EN EL TOP Y LA DIRECCION ES 'u' NI TAMPOCO SI LA PELOTA ESTA EN EL BOTTOM Y LA DIRECCION ES 'd' PORQUE ESO YA SE CONTROLA ABAJO
		    	*direction = 'u';
		    else if(x == 2)
				*direction = 'd';
		}
		else{ //SI LLEGA A TOPE DE LA MATRIZ 2 PERO NO LLEGA AL BOTTOM NI A 1 ANTES DEL BOTTOM
			*ball_row >>= 1;
		}
		*ball_col = 0b11111110;
		*ball_matrix = 1;
	}
	else if(*ball_col == 0b01111111 && *ball_matrix == 1){//SI LLEGA A TOPE DE LA MATRIZ 1
		*flag = 1;
	}
	else{//SI NO LLEGA A TOPE DE NINGUNA MATRIZ
		if(*ball_row == 0b00000001){//SI NO LLEGA A TOPE DE NINGUNA MATRIZ PERO LLEGA AL BOTTOM
			*ball_row <<= 1;
			*direction = 'u';
		}
		else{//SI NO LLEGA A TOPE DE NINGUNA MATRIZ NI TAMPOCO AL BOTTOM
			*ball_row >>= 1;
		}
		//SE RECORRE PARA QUE A LA PROXIMA ABRA LA OTRA COLUMNA Y SE VEA EL MOVIMIENTO(ES IMPORTANTE SUMARLE 1)
		*ball_col <<= 1;
		*ball_col += 1;
	}
}

void ping_pong_ball_going_up_right_left(uint8_t *ball_row, uint8_t *ball_matrix, uint8_t *ball_col, uint8_t *direction, uint8_t *flag){
	/*creo que la condicion de flag debe ir aqui porque no quiero que prenda ese led porque si no me apagará
	  los de la raqueta*/

	//PRENDE EL LED
	if(*ball_matrix == 1)
		ping_pong_open_row_ML1(*ball_row);
	else if(*ball_matrix == 2)
		ping_pong_open_row_ML2(*ball_row);

	if(*ball_col == 0b01111111 && *ball_matrix == 2){//SI LLEGA A TOPE DE LA MATRIZ 2
		//NUNCA VA A ENTRAR EN ESTA CONDICION PORQUE NUNCA VA ASER '0b10000000' EN EL TOPE DE LA
		// MATRIZ 2 YA QUE AL MOMENTO EN QUE LE DOY CON LA RAQUETA EN ALGUNA ESQUINA
		// DA COMO QUE LA VUELTA Y POR ESO NO REGRESA POR DONDE VINO SI NO UN LED ARRIBA O ABAJO

		/*if(*ball_row == 0b10000000){//SI LLEGA A TOPE DE LA MATRIZ 2 Y ADEMÁS LLEGA AL TOP
			*ball_row >>= 1;
			*direction = 'd';
		}*/
		if(*ball_row == 0b01000000){//SI LLEGA A TOPE DE LA MATRIZ 2 Y ADEMÁS LLEGA 1 ANTES DEL TOP
		    srand(HAL_GetTick());
		    min = 1, max = 6;
		    x = rand() % (max - min + 1) + min;
		    while(x--){
		    	*ball_row >>= 1;
		    }
		    min= 1, max = 2;
		    x = rand() % (max - min + 1) + min;
		    if(x == 1) //NO PASA NADA SI LA PELOTA ESTA EN EL TOP Y LA DIRECCION ES 'u' NI TAMPOCO SI LA PELOTA ESTA EN EL BOTTOM Y LA DIRECCION ES 'd' PORQUE ESO YA SE CONTROLA ABAJO
		    	*direction = 'u';
		    else if(x == 2)
				*direction = 'd';
		}
		else{ //SI LLEGA A TOPE DE LA MATRIZ 2 PERO NO LLEGA AL TOP NI A 1 ANTES DEL TOP
			*ball_row <<= 1;
		}
		*ball_col = 0b11111110;
		*ball_matrix = 1;
	}
	else if(*ball_col == 0b01111111 && *ball_matrix == 1){//SI LLEGA A TOPE DE LA MATRIZ 1
		*flag = 1;
	}
	else{//SI NO LLEGA A TOPE DE NINGUNA MATRIZ
		if(*ball_row == 0b10000000){//SI NO LLEGA A TOPE DE NINGUNA MATRIZ PERO LLEGA AL TOP
			*ball_row >>= 1;
			*direction = 'd';
		}
		else{//SI NO LLEGA A TOPE DE NINGUNA MATRIZ NI TAMPOCO AL TOP
			*ball_row <<= 1;
		}
		//SE RECORRE PARA QUE A LA PROXIMA ABRA LA OTRA COLUMNA Y SE VEA EL MOVIMIENTO(ES IMPORTANTE SUMARLE 1)
		*ball_col <<= 1;
		*ball_col += 1;
	}
}

void ping_pong_ball_going_down_left_right(uint8_t *ball_row, uint8_t *ball_matrix, uint8_t *ball_col, uint8_t *direction, uint8_t *flag){
	/*creo que la condicion de flag debe ir aqui porque no quiero que prenda ese led porque si no me apagará
	  los de la raqueta*/

	//PRENDE EL LED
	if(*ball_matrix == 1)
		ping_pong_open_row_ML1(*ball_row);
	else if(*ball_matrix == 2)
		ping_pong_open_row_ML2(*ball_row);

	if(*ball_col == 0b11111110 && *ball_matrix == 1){//SI LLEGA A TOPE DE LA MATRIZ 1
		//NUNCA VA A ENTRAR EN ESTA CONDICION PORQUE NUNCA VA ASER '0b00000001' EN EL TOPE DE LA
		// MATRIZ 1 YA QUE AL MOMENTO EN QUE LE DOY CON LA RAQUETA EN ALGUNA ESQUINA
		// DA COMO QUE LA VUELTA Y POR ESO NO REGRESA POR DONDE VINO SI NO UN LED ARRIBA O ABAJO

		/*if(*ball_row == 0b00000001){//SI LLEGA A TOPE DE LA MATRIZ 1 Y ADEMÁS LLEGA AL BOTTOM
			*ball_row <<= 1;
			*direction = 'u';
		}*/
		if(*ball_row == 0b00000010){//SI LLEGA A TOPE DE LA MATRIZ 1 Y ADEMÁS LLEGA 1 ANTES DEL BOTTOM
		    srand(HAL_GetTick());
		    min = 1, max = 6;
		    x = rand() % (max - min + 1) + min;
		    while(x--){
		    	*ball_row <<= 1;
		    }
		    min= 1, max = 2;
		    x = rand() % (max - min + 1) + min;
		    if(x == 1) //NO PASA NADA SI LA PELOTA ESTA EN EL TOP Y LA DIRECCION ES 'u' NI TAMPOCO SI LA PELOTA ESTA EN EL BOTTOM Y LA DIRECCION ES 'd' PORQUE ESO YA SE CONTROLA ABAJO
		    	*direction = 'u';
		    else if(x == 2)
				*direction = 'd';
		}
		else{ //SI LLEGA A TOPE DE LA MATRIZ 1 PERO NO LLEGA AL BOTTOM NI A 1 ANTES DEL BOTTOM
			*ball_row >>= 1;
		}
		*ball_col = 0b01111111;
		*ball_matrix = 2;
	}
	else if(*ball_col == 0b11111110 && *ball_matrix == 2){//SI LLEGA A TOPE DE LA MATRIZ 2
		*flag = 1;
	}
	else{//SI NO LLEGA A TOPE DE NINGUNA MATRIZ
		if(*ball_row == 0b00000001){//SI NO LLEGA A TOPE DE NINGUNA MATRIZ PERO LLEGA AL BOTTOM
			*ball_row <<= 1;
			*direction = 'u';
		}
		else{//SI NO LLEGA A TOPE DE NINGUNA MATRIZ NI TAMPOCO AL BOTTOM
			*ball_row >>= 1;
		}
		//SE RECORRE PARA QUE A LA PROXIMA ABRA LA OTRA COLUMNA Y SE VEA EL MOVIMIENTO(ES IMPORTANTE SUMARLE 128)
		*ball_col >>= 1;
		*ball_col += 128;
	}
}

void ping_pong_ball_going_up_left_right(uint8_t *ball_row, uint8_t *ball_matrix, uint8_t *ball_col, uint8_t *direction, uint8_t *flag){
	/*creo que la condicion de flag debe ir aqui porque no quiero que prenda ese led porque si no me apagará
	  los de la raqueta*/

	//PRENDE EL LED
	if(*ball_matrix == 1)
		ping_pong_open_row_ML1(*ball_row);
	else if(*ball_matrix == 2)
		ping_pong_open_row_ML2(*ball_row);

	if(*ball_col == 0b11111110 && *ball_matrix == 1){//SI LLEGA A TOPE DE LA MATRIZ 1
		//NUNCA VA A ENTRAR EN ESTA CONDICION PORQUE NUNCA VA ASER '0b10000000' EN EL TOPE DE LA
		// MATRIZ 1 YA QUE AL MOMENTO EN QUE LE DOY CON LA RAQUETA EN ALGUNA ESQUINA
		// DA COMO QUE LA VUELTA Y POR ESO NO REGRESA POR DONDE VINO SI NO UN LED ARRIBA O ABAJO

		/*if(*ball_row == 0b10000000){//SI LLEGA A TOPE DE LA MATRIZ 1 Y ADEMÁS LLEGA AL TOP
			*ball_row >>= 1;
			*direction = 'd';
		}*/
		if(*ball_row == 0b01000000){//SI LLEGA A TOPE DE LA MATRIZ 1 Y ADEMÁS LLEGA 1 ANTES DEL TOP
		    srand(HAL_GetTick());
		    min = 1, max = 6;
		    x = rand() % (max - min + 1) + min;
		    while(x--){
		    	*ball_row >>= 1;
		    }
		    min= 1, max = 2;
		    x = rand() % (max - min + 1) + min;
		    if(x == 1) //NO PASA NADA SI LA PELOTA ESTA EN EL TOP Y LA DIRECCION ES 'u' NI TAMPOCO SI LA PELOTA ESTA EN EL BOTTOM Y LA DIRECCION ES 'd' PORQUE ESO YA SE CONTROLA ABAJO
		    	*direction = 'u';
		    else if(x == 2)
				*direction = 'd';
		}
		else{ //SI LLEGA A TOPE DE LA MATRIZ 1 PERO NO LLEGA AL TOP NI A 1 ANTES DEL TOP
			*ball_row <<= 1;
		}
		*ball_col = 0b01111111;
		*ball_matrix = 2;
	}
	else if(*ball_col == 0b11111110 && *ball_matrix == 2){//SI LLEGA A TOPE DE LA MATRIZ 2
		*flag = 1;
	}
	else{//SI NO LLEGA A TOPE DE NINGUNA MATRIZ
		if(*ball_row == 0b10000000){//SI NO LLEGA A TOPE DE NINGUNA MATRIZ PERO LLEGA AL TOP
			*ball_row >>= 1;
			*direction = 'd';
		}
		else{//SI NO LLEGA A TOPE DE NINGUNA MATRIZ NI TAMPOCO AL TOP
			*ball_row <<= 1;
		}
		//SE RECORRE PARA QUE A LA PROXIMA ABRA LA OTRA COLUMNA Y SE VEA EL MOVIMIENTO(ES IMPORTANTE SUMARLE 128)
		*ball_col >>= 1;
		*ball_col += 128;
	}
}

//NO EXISTE EL MOVIMIENTO HORIZONTAL


void ping_pong_init(){
	uint8_t rackets_rows = 0b00011000,
			ball1_col = 0b11111110, ball1_row = 0b10000000,
			ball2_col = 0b01111111, ball2_row = 0b10000000;

	//SE ABRE COLUMNA PARA LA RAQUETA 1
	ping_pong_open_col_ML1(racket1_col);

	//SE ABRE COLUMNA PARA LA RAQUETA 2
	ping_pong_open_col_ML2(racket2_col);

	//SE ABREN FILAS PARA LA RAQUETA 1
	ping_pong_open_row_ML1(rackets_rows);

	//SE ABREN FILAS PARA LA RAQUETA 2
	ping_pong_open_row_ML2(rackets_rows);

	//while(KeyBoard_Matrix() != 'A'){};

	if(points_player1 + points_player2 < 9){
		if(p1){
			ping_pong_player1(rackets_rows, rackets_rows, ball1_col, ball1_row, 'd', 1);
		}
		else if(p2){
			ping_pong_player2(rackets_rows, rackets_rows, ball2_col, ball2_row, 'd', 2);
		}
	}
	else{
		//SE ESCRIBEN LOS NÚMEROS Y SE QUEDA ASÍ HASTA DARLE RESET(con el boton de reset del micro)
		switch(points_player1){
		    case 0:
		    	while(1){
		    		write_0(1);
		    		write_9(2);
		    	}
		        break;
		    case 1:
		    	while(1){
		    		write_1(1);
		    		write_8(2);
		    	}
		        break;
		    case 2:
		    	while(1){
		    		write_2(1);
		    		write_7(2);
		    	}
		    	break;
		    case 3:
		    	while(1){
		    		write_3(1);
		    		write_6(2);
		    	}
		    	break;
		    case 4:
		    	while(1){
		    		write_4(1);
		    		write_5(2);
		    	}
		    	break;
		    case 5:
		    	while(1){
		    		write_5(1);
		    		write_4(2);
		    	}
		    	break;
		    case 6:
		    	while(1){
		    		write_6(1);
		    		write_3(2);
		    	}
		    	break;
		    case 7:
		    	while(1){
		    		write_7(1);
		    		write_2(2);
		    	}
		    	break;
		    case 8:
		    	while(1){
		    		write_8(1);
		    		write_1(2);
		    	}
		    	break;
		    case 9:
		    	while(1){
		    		write_9(1);
		    		write_0(2);
		    	}
		    	break;
		    default:
		        break;
		}
	}

}

void ping_pong_joystick1(uint8_t *racket1_rows, uint8_t i){
//HAZ UNA VARIABLE GLOBAL, LUEGO CREA UNA FUNCION QUE RECIBA A 'Joystick_Values' POR REFERENCIA
// Y ASIGNALE ESA DIRECCION A TU VARIABLE GLOBAL, DE ESTA FORMA CADA QUE SE MODIFIQUE 'Joystick_Values'
// TU VARIABLE GLOBAL APUNTARA A ESA DIRECCION DE MEMORIA Y SIEMPRE TENDRA EL VALOR NUEVO

//PARA HACERLO DE UNA MANERA MAS FACIL MEJOR SE UTILIZÓ 'extern'

//AL PONERLE 'i == 2' LOGRO HACER QUE LA RAQUETA SE MUEVA MAS LENTO Y LOGRE CAPTAR CUANDO YO SOLO LA QUIERO MOVER
//UN SOLO ESPACIO O TOTALMENTE HACÍA LOS EXTREMOS, ES DECIR, LOGRO HACER QUE EL JOYSTICK NO SEA TAN SENSIBLE.
//ESTO SE LOGRO HACIENDO 1 SOLO RECORRIMIENTO POR CADA 6O ITERACIONES DE 1 MILISEGUNDO(cada una) DEL CICLO 'for'
	if(i == 2){ //(cabe recalcar que aquí no importa el número, con que sea '==' basta
		if(Joystick_Values[0] > 2800){ //SI EL JOYSTICK APUNTA HACÍA ARRIBA
			if(*racket1_rows != 0b11000000){ //AQUI CONTROLA PARA QUE NO SIGA SUBIENDO SI YA LLLEGO A TOPE
				*racket1_rows <<= 1;
			}
		}
		else if(Joystick_Values[0] > 2100 && Joystick_Values[0] < 2800){}//SI EL JOYSTICK ESTÁ EN EL CENTRO
		else if(Joystick_Values[0] < 2100){//SI EL JOYSTICK APUNTA HACÍA ABAJO
			if(*racket1_rows != 0b00000011){ //AQUI CONTROLA PARA QUE NO SIGA BAJANDO SI YA LLLEGO A TOPE
				*racket1_rows >>= 1;
			}
		}
	}
}
void ping_pong_joystick2(uint8_t *racket2_rows, uint8_t i){
	//HAZ UNA VARIABLE GLOBAL, LUEGO CREA UNA FUNCION QUE RECIBA A 'Joystick_Values' POR REFERENCIA
	// Y ASIGNALE ESA DIRECCION A TU VARIABLE GLOBAL, DE ESTA FORMA CADA QUE SE MODIFIQUE 'Joystick_Values'
	// TU VARIABLE GLOBAL APUNTARA A ESA DIRECCION DE MEMORIA Y SIEMPRE TENDRA EL VALOR NUEVO

	//PARA HACERLO DE UNA MANERA MAS FACIL MEJOR SE UTILIZÓ 'extern'

	//AL PONERLE 'i == 2' LOGRO HACER QUE LA RAQUETA SE MUEVA MAS LENTO Y LOGRE CAPTAR CUANDO YO SOLO LA QUIERO MOVER
	//UN SOLO ESPACIO O TOTALMENTE HACÍA LOS EXTREMOS, ES DECIR, LOGRO HACER QUE EL JOYSTICK NO SEA TAN SENSIBLE.
	//ESTO SE LOGRO HACIENDO 1 SOLO RECORRIMIENTO POR CADA 6O ITERACIONES DE 1 MILISEGUNDO(cada una) DEL CICLO 'for'
	if(i == 2){ //(cabe recalcar que aquí no importa el número, con que sea '==' basta
		if(Joystick_Values[2] > 3000){ //SI EL JOYSTICK APUNTA HACÍA ARRIBA //OJITO QUE AQUI LE PUSE 3000 POR QUE SI NO A CADA RATO SE ME IBA PARA ARRIBA
			if(*racket2_rows != 0b11000000){ //AQUI CONTROLA PARA QUE NO SIGA SUBIENDO SI YA LLLEGO A TOPE
				*racket2_rows <<= 1;
			}
		}
		else if(Joystick_Values[2] > 2100 && Joystick_Values[2] < 2800){}//SI EL JOYSTICK ESTÁ EN EL CENTRO
		else if(Joystick_Values[2] < 2100){//SI EL JOYSTICK APUNTA HACÍA ABAJO
			if(*racket2_rows != 0b00000011){ //AQUI CONTROLA PARA QUE NO SIGA BAJANDO SI YA LLLEGO A TOPE
				*racket2_rows >>= 1;
			}
		}
	}
}

void ping_pong_player1(uint8_t racket1_rows, uint8_t racket2_rows, uint8_t ball_col, uint8_t ball_row, uint8_t direction, uint8_t ball_matrix){
	uint8_t aux, prev_row, flag = 0; //'flag' ES PARA CUANDO EL BALON YA ESTE EN LA COLUMNA 0 Y LE VAYA A PEGAR EL PLAYER1
	uint8_t b_r, b_m, b_c, dir, f;

	while(1){
		for(int i = 0; i < 60; i++){
			//AQUI SE LLAMA A LA FUNCIÓN PARA SABER HACÍA A DONDE SE TIENE QUE MOVER LA RAQUETA
			ping_pong_joystick1(&racket1_rows, i);

			//SE ABRE COLUMNA PARA LA RAQUETA 1
			ping_pong_open_col_ML1(racket1_col);
			//SE ABREN FILAS PARA LA RAQUETA 1
			ping_pong_open_row_ML1(racket1_rows);

			//AQUI SE LLAMA A LA FUNCIÓN PARA SABER HACÍA A DONDE SE TIENE QUE MOVER LA RAQUETA
			ping_pong_joystick2(&racket2_rows, i);

			//SE ABRE COLUMNA PARA LA RAQUETA 2
			ping_pong_open_col_ML2(racket2_col);
			//SE ABREN FILAS PARA LA RAQUETA 2
			ping_pong_open_row_ML2(racket2_rows);

			//SE TIENE QUE CERRAR LA COLUMNA Y LAS ROWS PARA QUE NO SE PASE LA INFORMACION
			//(podría simplemente cerras las rows porque en el momento en el que yo abro la
			// columna de la ball 'ball_col' se cierran las otras, pero mejor lo dejamos así
			// por cualquier cosa)
			ping_pong_open_col_ML1(0b11111111);
			ping_pong_open_col_ML2(0b11111111);
			ping_pong_open_row_ML1(0b00000000);
			ping_pong_open_row_ML2(0b00000000);

			//SE ABRE COLUMNA PARA EL BALON
			if(ball_matrix == 1)
				ping_pong_open_col_ML1(ball_col);
			else if(ball_matrix == 2)
				ping_pong_open_col_ML2(ball_col);

			//PARA SIMULAR EL MOVIMIENTO LENTO DE LA PELOTA TENGO QUE PRENDER Y APAGAR MUCHAS VECES EN EL MISMO
			//LUGAR, Y LUEGO MOVER LA PELOTA (por lo tanto, si es en el mismo lugar no se tienen que modificar mis variables originales)
			b_r = ball_row, b_m = ball_matrix, b_c = ball_col, dir = direction, f = flag;
			if(direction == 'd'){//SI BAJA
				ping_pong_ball_going_down_right_left(&b_r, &b_m, &b_c, &dir, &f); //OJO: se pasa por referencia
			}
			else if(direction == 'u'){//SI SUBE
				ping_pong_ball_going_up_right_left(&b_r, &b_m, &b_c, &dir, &f);
			}
			//NO EXISTE EL MOVIMIENTO HORIZONTAL

			//SE TIENE QUE CERRAR LA COLUMNA Y LAS ROWS PARA QUE NO SE PASE LA INFORMACION
			//(podría simplemente cerras las rows porque en el momento en el que yo abro la
			// columna de las raqutas 'racket1_col' y 'racket2_col' se cierran las otras,
			// pero mejor lo dejamos así por cualquier cosa)
			ping_pong_open_col_ML1(0b11111111);
			ping_pong_open_col_ML2(0b11111111);
			ping_pong_open_row_ML1(0b00000000);
			ping_pong_open_row_ML2(0b00000000);

			HAL_Delay(1); //ES UN PEQUEÑO DELAY PARA QUE EL 'for' NO VAYA TAN RAPIDO PERO NO AFECTA PARA LA VISTA HUMANA NI TAMPOCO PARA EL JOYSTICK
		}

		//SE ABRE COLUMNA PARA EL BALON
		if(ball_matrix == 1)
			ping_pong_open_col_ML1(ball_col);
		else if(ball_matrix == 2)
			ping_pong_open_col_ML2(ball_col);

		//GUARDO LA ANTERIOR FILA PARA AYUDARME AL MOMENTO DE QUE PLAYER1 TIRE
		aux = ball_row; //OJO CON ESTO(parte1)

		if(direction == 'd'){//SI BAJA
			ping_pong_ball_going_down_right_left(&ball_row, &ball_matrix, &ball_col, &direction, &flag); //OJO: se pasa por referencia
		}
		else if(direction == 'u'){//SI SUBE
			ping_pong_ball_going_up_right_left(&ball_row, &ball_matrix, &ball_col, &direction, &flag);
		}
		//NO EXISTE EL MOVIMIENTO HORIZONTAL


		//SE TIENE QUE CERRAR LA COLUMNA Y LAS ROWS PARA QUE NO SE PASE LA INFORMACION
		ping_pong_open_col_ML1(0b11111111);
		ping_pong_open_col_ML2(0b11111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_row_ML2(0b00000000);


		if(flag){
			//SE APLICA EL OPERADOR '&' PARA SABER SI LA RAQUETA LO TAPÓ O NO
			if((racket1_rows & ball_row) > 0){
				//SE APLICA EL OPERADOR '|' PARA SABER SI LA PELOTA LLEGÓ POR LAS ESQUINAS O NO
				if((racket1_rows | prev_row) == racket1_rows){
					//SE APLICA EL OPERADOR '^' PARA SABER SI LA PELOTA LLEGÓ POR ARRIBA O ABAJO
					if((racket1_rows ^ prev_row) < prev_row){//LA PELOTA LLEGÓ POR ARRIBA
						if((racket1_rows & 1) == 1){//SI LA PELOTA LLEGÓ POR ARRIBA Y LA RAQUETA ESTA HASTA ABAJO, LA PELOTA VUELVE A IR HACÍA ARRIBA
							ball_row = 0b00000001;//(según yo, 'ball_row' ya esta con ese valor, entonces si no se lo asignamos no pasaría nada malo)
							direction = 'u';
						}
						else{//SI LA PELOTA LLEGÓ POR ARRIBA Y LA RAQUETA NO ESTA HASTA ABAJO, LA PELOTA VA HACÍA ABAJO
							ball_row >>= 1;
							direction = 'd';
						}
					}
					else if((racket1_rows ^ prev_row) > prev_row){//LA PELOTA LLEGÓ POR ABAJO
						if((racket1_rows & 128) == 128){//SI LA PELOTA LLEGÓ POR ABAJO Y LA RAQUETA ESTA HASTA ARRIBA, LA PELOTA VUELVE A IR HACÍA ABAJO
							ball_row = 0b10000000;//(según yo, 'ball_row' ya esta con ese valor, entonces si no se lo asignamos no pasaría nada malo)
							direction = 'd';
						}
						else{//SI LA PELOTA LLEGÓ POR ABAJO Y LA RAQUETA NO ESTA HASTA ARRIBA, LA PELOTA VA HACÍA ARRIBA
							ball_row <<= 1;
							direction = 'u';
						}
					}
				}
				else if((racket1_rows | prev_row) != racket1_rows){
					if(prev_row > racket1_rows){//LA PELOTA LLEGÓ POR LA ESQUINA DE ARRIBA
						ball_row >>= 1;
						direction = 'd';
					}
					else if(prev_row < racket1_rows){//LA PELOTA LLEGÓ POR LA ESQUINA DE ABAJO
						ball_row <<= 1;
						direction = 'u';
					}
				}
				ball_col = 0b10111111;
			}
			else if((racket1_rows & ball_row) == 0){
				direction = 'r';
			}
			break;
		}

		prev_row = aux; //OJO CON ESTO(parte2)
	}

	if(direction == 'd'){
		ping_pong_player2(racket1_rows, racket2_rows, ball_col, ball_row, 'd', 1);
	}
	else if(direction == 'u'){
		ping_pong_player2(racket1_rows, racket2_rows, ball_col, ball_row, 'u', 1);
	}
	else if(direction == 'r'){
		//EMPIEZA ÉL OTRA VEZ, SE SUMA PUNTAJE Y SE REINICIA
		p1 = 1;
		p2 = 0;
		points_player2++;
		ping_pong_init();
	}
}

void ping_pong_player2(uint8_t racket1_rows, uint8_t racket2_rows, uint8_t ball_col, uint8_t ball_row, uint8_t direction, uint8_t ball_matrix){
	uint8_t aux, prev_row, flag = 0; //'flag' ES PARA CUANDO EL BALON YA ESTE EN LA COLUMNA 7 Y LE VAYA A PEGAR EL PLAYER2
	uint8_t b_r, b_m, b_c, dir, f;

	while(1){
		for(int i = 0; i < 60; i++){
			//AQUI SE LLAMA A LA FUNCIÓN PARA SABER HACÍA A DONDE SE TIENE QUE MOVER LA RAQUETA
			ping_pong_joystick1(&racket1_rows, i);

			//SE ABRE COLUMNA PARA LA RAQUETA 1
			ping_pong_open_col_ML1(racket1_col);
			//SE ABREN FILAS PARA LA RAQUETA 1
			ping_pong_open_row_ML1(racket1_rows);

			//AQUI SE LLAMA A LA FUNCIÓN PARA SABER HACÍA A DONDE SE TIENE QUE MOVER LA RAQUETA
			ping_pong_joystick2(&racket2_rows, i);

			//SE ABRE COLUMNA PARA LA RAQUETA 2
			ping_pong_open_col_ML2(racket2_col);
			//SE ABREN FILAS PARA LA RAQUETA 2
			ping_pong_open_row_ML2(racket2_rows);

			//SE TIENE QUE CERRAR LA COLUMNA Y LAS ROWS PARA QUE NO SE PASE LA INFORMACION
			//(podría simplemente cerras las rows porque en el momento en el que yo abro la
			// columna de la ball 'ball_col' se cierran las otras, pero mejor lo dejamos así
			// por cualquier cosa)
			ping_pong_open_col_ML1(0b11111111);
			ping_pong_open_col_ML2(0b11111111);
			ping_pong_open_row_ML1(0b00000000);
			ping_pong_open_row_ML2(0b00000000);

			//SE ABRE COLUMNA PARA EL BALON
			if(ball_matrix == 1)
				ping_pong_open_col_ML1(ball_col);
			else if(ball_matrix == 2)
				ping_pong_open_col_ML2(ball_col);

			//PARA SIMULAR EL MOVIMIENTO LENTO DE LA PELOTA TENGO QUE PRENDER Y APAGAR MUCHAS VECES EN EL MISMO
			//LUGAR, Y LUEGO MOVER LA PELOTA (por lo tanto, si es en el mismo lugar no se tienen que modificar mis variables originales)
			b_r = ball_row, b_m = ball_matrix, b_c = ball_col, dir = direction, f = flag;
			if(direction == 'd'){//SI BAJA
				ping_pong_ball_going_down_left_right(&b_r, &b_m, &b_c, &dir, &f); //OJO: se pasa por referencia
			}
			else if(direction == 'u'){//SI SUBE
				ping_pong_ball_going_up_left_right(&b_r, &b_m, &b_c, &dir, &f);
			}
			//NO EXISTE EL MOVIMIENTO HORIZONTAL

			//SE TIENE QUE CERRAR LA COLUMNA Y LAS ROWS PARA QUE NO SE PASE LA INFORMACION
			//(podría simplemente cerras las rows porque en el momento en el que yo abro la
			// columna de las raqutas 'racket1_col' y 'racket2_col' se cierran las otras,
			// pero mejor lo dejamos así por cualquier cosa)
			ping_pong_open_col_ML1(0b11111111);
			ping_pong_open_col_ML2(0b11111111);
			ping_pong_open_row_ML1(0b00000000);
			ping_pong_open_row_ML2(0b00000000);

			HAL_Delay(1); //ES UN PEQUEÑO DELAY PARA QUE EL 'for' NO VAYA TAN RAPIDO PERO NO AFECTA PARA LA VISTA HUMANA NI TAMPOCO PARA EL JOYSTICK
		}

		//SE ABRE COLUMNA PARA EL BALON
		if(ball_matrix == 1)
			ping_pong_open_col_ML1(ball_col);
		else if(ball_matrix == 2)
			ping_pong_open_col_ML2(ball_col);

		//GUARDO LA ANTERIOR FILA PARA AYUDARME AL MOMENTO DE QUE PLAYER2 TIRE
		aux = ball_row; //OJO CON ESTO(parte1)

		if(direction == 'd'){//SI BAJA
			ping_pong_ball_going_down_left_right(&ball_row, &ball_matrix, &ball_col, &direction, &flag); //OJO: se pasa por referencia
		}
		else if(direction == 'u'){//SI SUBE
			ping_pong_ball_going_up_left_right(&ball_row, &ball_matrix, &ball_col, &direction, &flag);
		}
		//NO EXISTE EL MOVIMIENTO HORIZONTAL


		//SE TIENE QUE CERRAR LA COLUMNA Y LAS ROWS PARA QUE NO SE PASE LA INFORMACION
		ping_pong_open_col_ML1(0b11111111);
		ping_pong_open_col_ML2(0b11111111);
		ping_pong_open_row_ML1(0b00000000);
		ping_pong_open_row_ML2(0b00000000);

		if(flag){
			//SE APLICA EL OPERADOR '&' PARA SABER SI LA RAQUETA LO TAPÓ O NO
			if((racket2_rows & ball_row) > 0){
				//SE APLICA EL OPERADOR '|' PARA SABER SI LA PELOTA LLEGÓ POR LAS ESQUINAS O NO
				if((racket2_rows | prev_row) == racket2_rows){
					//SE APLICA EL OPERADOR '^' PARA SABER SI LA PELOTA LLEGÓ POR ARRIBA O ABAJO
					if((racket2_rows ^ prev_row) < prev_row){//LA PELOTA LLEGÓ POR ARRIBA
						if((racket2_rows & 1) == 1){//SI LA PELOTA LLEGÓ POR ARRIBA Y LA RAQUETA ESTA HASTA ABAJO, LA PELOTA VUELVE A IR HACÍA ARRIBA
							ball_row = 0b00000001;//(según yo, 'ball_row' ya esta con ese valor, entonces si no se lo asignamos no pasaría nada malo)
							direction = 'u';
						}
						else{//SI LA PELOTA LLEGÓ POR ARRIBA Y LA RAQUETA NO ESTA HASTA ABAJO, LA PELOTA VA HACÍA ABAJO
							ball_row >>= 1;
							direction = 'd';
						}
					}
					else if((racket2_rows ^ prev_row) > prev_row){//LA PELOTA LLEGÓ POR ABAJO
						if((racket2_rows & 128) == 128){//SI LA PELOTA LLEGÓ POR ABAJO Y LA RAQUETA ESTA HASTA ARRIBA, LA PELOTA VUELVE A IR HACÍA ABAJO
							ball_row = 0b10000000;//(según yo, 'ball_row' ya esta con ese valor, entonces si no se lo asignamos no pasaría nada malo)
							direction = 'd';
						}
						else{//SI LA PELOTA LLEGÓ POR ABAJO Y LA RAQUETA NO ESTA HASTA ARRIBA, LA PELOTA VA HACÍA ARRIBA
							ball_row <<= 1;
							direction = 'u';
						}
					}
				}
				else if((racket2_rows | prev_row) != racket2_rows){
					if(prev_row > racket2_rows){//LA PELOTA LLEGÓ POR LA ESQUINA DE ARRIBA
						ball_row >>= 1;
						direction = 'd';
					}
					else if(prev_row < racket2_rows){//LA PELOTA LLEGÓ POR LA ESQUINA DE ABAJO
						ball_row <<= 1;
						direction = 'u';
					}
				}
				ball_col = 0b11111101;
			}
			else if((racket2_rows & ball_row) == 0){
				direction = 'r';
			}
			break;
		}

		prev_row = aux; //OJO CON ESTO(parte2)

	}

	if(direction == 'd'){
		ping_pong_player1(racket1_rows, racket2_rows, ball_col, ball_row, 'd', 2);
	}
	else if(direction == 'u'){
		ping_pong_player1(racket1_rows, racket2_rows, ball_col, ball_row, 'u', 2);
	}
	else if(direction == 'r'){
		//EMPIEZA ÉL OTRA VEZ, SE SUMA PUNTAJE Y SE REINICIA
		p1 = 0;
		p2 = 1;
		points_player1++;
		ping_pong_init();
	}
}
//PING-PONG


//HOCKEY
void hockey_open_col_ML1(uint8_t bits){
	uint8_t bit;

	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C7_GPIO_Port, ML1_C7_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C6_GPIO_Port, ML1_C6_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C5_GPIO_Port, ML1_C5_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C4_GPIO_Port, ML1_C4_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C3_GPIO_Port, ML1_C3_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C2_GPIO_Port, ML1_C2_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C1_GPIO_Port, ML1_C1_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_C0_GPIO_Port, ML1_C0_Pin, bit);
}

void hockey_open_row_ML1(uint8_t bits){
	uint8_t bit;

	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F7_GPIO_Port, ML1_F7_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F6_GPIO_Port, ML1_F6_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F5_GPIO_Port, ML1_F5_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F4_GPIO_Port, ML1_F4_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F3_GPIO_Port, ML1_F3_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F2_GPIO_Port, ML1_F2_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F1_GPIO_Port, ML1_F1_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML1_F0_GPIO_Port, ML1_F0_Pin, bit);
}

void hockey_open_col_ML2(uint8_t bits){
	uint8_t bit;

	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C7_GPIO_Port, ML2_C7_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C6_GPIO_Port, ML2_C6_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C5_GPIO_Port, ML2_C5_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C4_GPIO_Port, ML2_C4_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C3_GPIO_Port, ML2_C3_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C2_GPIO_Port, ML2_C2_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C1_GPIO_Port, ML2_C1_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_C0_GPIO_Port, ML2_C0_Pin, bit);
}

void hockey_open_row_ML2(uint8_t bits){
	uint8_t bit;

	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F7_GPIO_Port, ML2_F7_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F6_GPIO_Port, ML2_F6_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F5_GPIO_Port, ML2_F5_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F4_GPIO_Port, ML2_F4_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F3_GPIO_Port, ML2_F3_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F2_GPIO_Port, ML2_F2_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F1_GPIO_Port, ML2_F1_Pin, bit);
	bit = bits&1;
	bits >>= 1;
	HAL_GPIO_WritePin(ML2_F0_GPIO_Port, ML2_F0_Pin, bit);
}

void hockey_close_col_rows(){
	hockey_open_col_ML1(close_col);
	hockey_open_col_ML2(close_col);
	hockey_open_row_ML1(close_rows);
	hockey_open_row_ML2(close_rows);
}

void hockey_init(){
	uint8_t player1_col = 0b10111111, player1_row = 0b00010000,
			player2_col = 0b11111101, player2_row = 0b00010000,
			ball1_col = 0b11111110, ball1_row = 0b00010000,
			ball2_col = 0b01111111, ball2_row = 0b00010000;

	//SE ABRE COLUMNA PARA GOAL1
	hockey_open_col_ML1(goal1_col);
	//SE ABRE COLUMNA PARA GOAL2
	hockey_open_col_ML2(goal2_col);

	//SE ABREN FILAS PARA LA GOAL1
	hockey_open_row_ML1(goal1_rows);
	//SE ABREN FILAS PARA LA GOAL2
	hockey_open_row_ML2(goal2_rows);

	hockey_close_col_rows();//SE CIERRA COLUMNAS Y FILAS

	//SE ABRE COLUMNA PARA EL PLAYER1
	hockey_open_col_ML1(player1_col);
	//SE ABRE COLUMNA PARA EL PLAYER2
	hockey_open_col_ML2(player2_col);

	//SE ABRE FILA PARA EL PLAYER1
	hockey_open_row_ML1(player1_row);
	//SE ABRE FILA PARA EL PLAYER2
	hockey_open_row_ML2(player2_row);

	hockey_close_col_rows();//SE CIERRA COLUMNAS Y FILAS

	//SIEMPRE INICIARÁ EL PLAYER1
	//SE ABRE COLUMNA PARA BALL1
	hockey_open_col_ML1(ball1_col);
	//SE ABRE FILA PARA BALL1
	hockey_open_row_ML1(ball1_row);

	if(points_player1 + points_player2 < 9){
		if(p1){
			hockey_player1(player1_col, player1_row, player2_col, player2_row, ball1_col, ball1_row, 0); //0 SIGNIFICA QUE NO SE MUEVE
		}
		else if(p2){
			hockey_player2(player1_col, player1_row, player2_col, player2_row, ball2_col, ball2_row, 0);//0 SIGNIFICA QUE NO SE MUEVE
		}
	}
	else{
		//SE ESCRIBEN LOS NÚMEROS Y SE QUEDA ASÍ HASTA DARLE RESET(con el boton de reset del micro)
		switch(points_player1){
		    case 0:
		    	while(1){
		    		write_0(1);
		    		write_9(2);
		    	}
		        break;
		    case 1:
		    	while(1){
		    		write_1(1);
		    		write_8(2);
		    	}
		        break;
		    case 2:
		    	while(1){
		    		write_2(1);
		    		write_7(2);
		    	}
		    	break;
		    case 3:
		    	while(1){
		    		write_3(1);
		    		write_6(2);
		    	}
		    	break;
		    case 4:
		    	while(1){
		    		write_4(1);
		    		write_5(2);
		    	}
		    	break;
		    case 5:
		    	while(1){
		    		write_5(1);
		    		write_4(2);
		    	}
		    	break;
		    case 6:
		    	while(1){
		    		write_6(1);
		    		write_3(2);
		    	}
		    	break;
		    case 7:
		    	while(1){
		    		write_7(1);
		    		write_2(2);
		    	}
		    	break;
		    case 8:
		    	while(1){
		    		write_8(1);
		    		write_1(2);
		    	}
		    	break;
		    case 9:
		    	while(1){
		    		write_9(1);
		    		write_0(2);
		    	}
		    	break;
		    default:
		        break;
		}
	}

}

void hockey_joystick1(uint8_t *player1_col, uint8_t *player1_row){
	int x = Joystick_Values[0], y = Joystick_Values[1];
	if(x > 2800 && (y > 2100 && y < 2800)){ //ARRIBA
		if(*player1_col != 0b11111110){ //TOPE DE CANCHA(es el tope del lado derecho viendo la matriz en su posición correcta)
			//LA ROW NO SE MUEVE, SOLO LA COL (ojo con sumarle 128)
			*player1_col >>= 1;
			*player1_col += 128;
		}
	}
	else if(x > 2800 && y > 2800){ //ARRIBA-DERECHA
		if(*player1_col != 0b11111110 && *player1_row != 0b00000001){ //TOPE DE CANCHA(es el tope del lado derecho y de abajo viendo la matriz en su posición correcta)
			//SE MUEVE LA ROW(no hay que sumarle nada) Y LA COL (se le suma 128)
			*player1_col >>= 1;
			*player1_col += 128;
			*player1_row >>= 1;
		}
	}
	else if(x > 2800 && y < 2100){ //ARRIBA-IZQUIERDA
		if(*player1_col != 0b11111110 && *player1_row != 0b10000000){ //TOPE DE CANCHA(es el tope del lado derecho y de arriba viendo la matriz en su posición correcta)
			//SE MUEVE LA ROW(no hay que sumarle nada) Y LA COL (se le suma 128)
			*player1_col >>= 1;
			*player1_col += 128;
			*player1_row <<= 1;
		}
	}
	else if((x > 2100 && x < 2800) && (y > 2100 && y < 2800)){ //CENTRO

	}
	else if((x > 2100 && x < 2800) && y > 2800){ //DERECHA
		if(*player1_col == 0b01111111 && *player1_row == 0b01000000){
			//SI QUIERES IR A LA DERECHA PERO ESTA EL POSTE IZQUIERDO NO SE HACE NADA (viendo la matriz según el juego)
		}
		else
			if(*player1_row != 0b00000001){ //TOPE DE CANCHA(es el tope de abajo viendo la matriz en su posición correcta)
				//LA COL NO SE MUEVE, SOLO MUEVO LA ROW(no hay que sumarle nada)
				*player1_row >>= 1;
			}
	}
	else if((x > 2100 && x < 2800) && y < 2100){ //IZQUIERDA
		if(*player1_col == 0b01111111 && *player1_row == 0b00000010){
			//SI QUIERES IR A LA IZQUIERDA Y ESTA EL POSTE DERECHO NO SE HACE NADA (viendo la matriz según el juego)
		}
		else
			if(*player1_row != 0b10000000){ //TOPE DE CANCHA(es el tope de arriba viendo la matriz en su posición correcta)
				//LA COL NO SE MUEVE, SOLO MUEVO LA ROW(no hay que sumarle nada)
				*player1_row <<= 1;
			}
	}
	else if(x < 2100 && (y > 2100 && y < 2800)){ //ABAJO
		if(*player1_col == 0b10111111 && (*player1_row == 0b00100000 || *player1_row == 0b00010000 || *player1_row == 0b00001000 || *player1_row == 0b00000100)){
			//SI QUIERES IR ABAJO PERO HAY UN POSTE O ENTRAS A LA PORTERIA NO SE HACE NADA (viendo la matriz según el juego)
		}
		else
			if(*player1_col != 0b01111111){//TOPE DE CANCHA(es el tope del lado izquierdo viendo la matriz en su posición correcta)
				//LA ROW NO SE MUEVE, SOLO LA COL (ojo con sumarle 1)
				*player1_col <<= 1;
				*player1_col += 1;
			}
	}
	else if(x < 2100 && y > 2800){ //ABAJO-DERECHA
		if(*player1_col == 0b10111111 && (*player1_row == 0b01000000 || *player1_row == 0b00100000 || *player1_row == 0b00010000 || *player1_row == 0b00001000)){
			//SI QUIERES IR ABAJO-DERECHA PERO HAY UN POSTE O ENTRAS A LA PORTERIA NO SE HACE NADA (viendo la matriz según el juego)
		}
		else{
			if(*player1_col != 0b01111111 && *player1_row != 0b00000001){ //TOPE DE CANCHA(es el tope del lado izquierdo y de abajo viendo la matriz en su posición correcta)
				//SE MUEVE LA ROW(no hay que sumarle nada) Y LA COL (se le suma 1)
				*player1_col <<= 1;
				*player1_col += 1;
				*player1_row >>= 1;
			}
		}
	}
	else if(x < 2100 && y < 2100){ //ABAJO-IZQUIERDA
		if(*player1_col == 0b10111111 && (*player1_row == 0b00010000 || *player1_row == 0b00001000 || *player1_row == 0b00000100 || *player1_row == 0b00000010)){
			//SI QUIERES IR ABAJO-IZQUIERDA PERO HAY UN POSTE O ENTRAS A LA PORTERIA NO SE HACE NADA (viendo la matriz según el juego)
		}
		else{
			if(*player1_col != 0b01111111 && *player1_row != 0b10000000){ //TOPE DE CANCHA(es el tope del lado izquierdo y de arriba viendo la matriz en su posición correcta)
				//SE MUEVE LA ROW(no hay que sumarle nada) Y LA COL (se le suma 1)
				*player1_col <<= 1;
				*player1_col += 1;
				*player1_row <<= 1;
			}
		}
	}
}

void hockey_joystick2(uint8_t *player2_col, uint8_t *player2_row){
	int x = Joystick_Values[2], y = Joystick_Values[3];
	if(x > 3000 && (y > 2100 && y < 2800)){ //ARRIBA  //OJITO QUE AQUI LE PUSE 3000 POR QUE SI NO A CADA RATO SE ME IBA PARA ARRIBA
		if(*player2_col != 0b01111111){ //TOPE DE CANCHA(es el tope del lado izquierdo viendo la matriz en su posición correcta)
			//LA ROW NO SE MUEVE, SOLO LA COL (ojo con sumarle 1)
			*player2_col <<= 1;
			*player2_col += 1;
		}
	}
	else if(x > 2800 && y > 2800){ //ARRIBA-DERECHA
		if(*player2_col != 0b01111111 && *player2_row != 0b10000000){ //TOPE DE CANCHA(es el tope del lado izquierdo y de arriba viendo la matriz en su posición correcta)
			//SE MUEVE LA ROW(no hay que sumarle nada) Y LA COL (se le suma 1)
			*player2_col <<= 1;
			*player2_col += 1;
			*player2_row <<= 1;
		}
	}
	else if(x > 2800 && y < 2100){ //ARRIBA-IZQUIERDA
		if(*player2_col != 0b01111111 && *player2_row != 0b00000001){ //TOPE DE CANCHA(es el tope del lado izquierdo y de abajo viendo la matriz en su posición correcta)
			//SE MUEVE LA ROW(no hay que sumarle nada) Y LA COL (se le suma 1)
			*player2_col <<= 1;
			*player2_col += 1;
			*player2_row >>= 1;
		}
	}
	else if((x > 2100 && x < 2800) && (y > 2100 && y < 2800)){ //CENTRO

	}
	else if((x > 2100 && x < 2800) && y > 2800){ //DERECHA
		if(*player2_col == 0b11111110 && *player2_row == 0b00000010){
			//SI QUIERES IR A LA DERECHA PERO ESTA EL POSTE IZQUIERDO NO SE HACE NADA (viendo la matriz según el juego)
		}
		else
			if(*player2_row != 0b10000000){ //TOPE DE CANCHA(es el tope de arriba viendo la matriz en su posición correcta)
				//LA COL NO SE MUEVE, SOLO MUEVO LA ROW(no hay que sumarle nada)
				*player2_row <<= 1;
			}
	}
	else if((x > 2100 && x < 2800) && y < 2100){ //IZQUIERDA
		if(*player2_col == 0b11111110 && *player2_row == 0b01000000){
			//SI QUIERES IR A LA IZQUIERDA Y ESTA EL POSTE DERECHO NO SE HACE NADA (viendo la matriz según el juego)
		}
		else
			if(*player2_row != 0b00000001){ //TOPE DE CANCHA(es el tope de abajo viendo la matriz en su posición correcta)
				//LA COL NO SE MUEVE, SOLO MUEVO LA ROW(no hay que sumarle nada)
				*player2_row >>= 1;
			}
	}
	else if(x < 2100 && (y > 2100 && y < 2800)){ //ABAJO
		if(*player2_col == 0b11111101 && (*player2_row == 0b00100000 || *player2_row == 0b00010000 || *player2_row == 0b00001000 || *player2_row == 0b00000100)){
			//SI QUIERES IR ABAJO PERO HAY UN POSTE O ENTRAS A LA PORTERIA NO SE HACE NADA (viendo la matriz según el juego)
		}
		else
			if(*player2_col != 0b11111110){//TOPE DE CANCHA(es el tope del lado derecho viendo la matriz en su posición correcta)
				//LA ROW NO SE MUEVE, SOLO LA COL (ojo con sumarle 128)
				*player2_col >>= 1;
				*player2_col += 128;
			}
	}
	else if(x < 2100 && y > 2800){ //ABAJO-DERECHA
		if(*player2_col == 0b11111101 && (*player2_row == 0b00010000 || *player2_row == 0b00001000 || *player2_row == 0b00000100 || *player2_row == 0b00000010)){
			//SI QUIERES IR ABAJO-DERECHA PERO HAY UN POSTE O ENTRAS A LA PORTERIA NO SE HACE NADA (viendo la matriz según el juego)
		}
		else{
			if(*player2_col != 0b11111110 && *player2_row != 0b10000000){ //TOPE DE CANCHA(es el tope del lado derecho y de arriba viendo la matriz en su posición correcta)
				//SE MUEVE LA ROW(no hay que sumarle nada) Y LA COL (se le suma 128)
				*player2_col >>= 1;
				*player2_col += 128;
				*player2_row <<= 1;
			}
		}
	}
	else if(x < 2100 && y < 2100){ //ABAJO-IZQUIERDA
		if(*player2_col == 0b11111101 && (*player2_row == 0b01000000 || *player2_row == 0b00100000 || *player2_row == 0b00010000 || *player2_row == 0b00001000)){
			//SI QUIERES IR ABAJO-IZQUIERDA PERO HAY UN POSTE O ENTRAS A LA PORTERIA NO SE HACE NADA (viendo la matriz según el juego)
		}
		else{
			if(*player2_col != 0b11111110 && *player2_row != 0b00000001){ //TOPE DE CANCHA(es el tope del lado izquierdo y de arriba viendo la matriz en su posición correcta)
				//SE MUEVE LA ROW(no hay que sumarle nada) Y LA COL (se le suma 128)
				*player2_col >>= 1;
				*player2_col += 128;
				*player2_row >>= 1;
			}
		}
	}
}

void kick(uint8_t prev_player_col, uint8_t prev_player_row, uint8_t ball_col, uint8_t ball_row, uint8_t *direction){
	uint8_t aux = prev_player_col;
	aux <<= 1;
	aux +=1;
	if(prev_player_col == ball_col){ //LE PEGO POR ABAJO O POR ARRIBA
		if(prev_player_row > ball_row) //LE PEGO POR ARRIBA
			*direction = 7;
		else if(prev_player_row < ball_row) //LE PEGO POR ABAJO
			*direction = 2;
	}
	else if((prev_player_col >> 1)+128 == ball_col){ //LE PEGO DEL LADO IZQUIERDO
		if(prev_player_row > ball_row) //LE PEGO POR ARRIBA
			*direction = 8;
		else if(prev_player_row == ball_row) //LE PEGO POR EL CENTRO
			*direction = 5;
		else if(prev_player_row < ball_row) //LE PEGO POR ABAJO
			*direction = 3;
	}
	else if(aux == ball_col){ //LE PEGO DEL LADO DERECHO //ESTO ME ESTABA CAUSANDO ERROR -> else if((prev_player_col << 1)+1 == ball_col), YO CREO QUE ESTABA HACIENDO COSAS RARAS POR ESO MEJOR SE LO ASIGNÉ A UNA VARIABLE DESDE EL INICIO
		if(prev_player_row > ball_row) //LE PEGO POR ARRIBA
			*direction = 6;
		else if(prev_player_row == ball_row) //LE PEGO POR EL CENTRO
			*direction = 4;
		else if(prev_player_row < ball_row) //LE PEGO POR ABAJO
			*direction = 1;
	}
}

void bounce_with_player(uint8_t *direction){
    switch(*direction) {
        case 1:
        	*direction = 8;
            break;
        case 2:
        	*direction = 7;
            break;
        case 3:
        	*direction = 6;
            break;
        case 4:
        	*direction = 5;
            break;
        case 5:
        	*direction = 4;
            break;
        case 6:
        	*direction = 3;
            break;
        case 7:
        	*direction = 2;
            break;
        case 8:
        	*direction = 1;
            break;
        default:
            break;
    }
}

void move_ball(uint8_t *ball_col, uint8_t *ball_row, uint8_t *direction, uint8_t *goal, uint8_t *matrix){
	//TODO ESTO SE HIZO VIENDO LA MATRIZ EN SU POSICION CORRECTA

	if(*matrix == 1){
		hockey_open_col_ML1(*ball_col);
		hockey_open_row_ML1(*ball_row);
	}
	else if(*matrix == 2){
		hockey_open_col_ML2(*ball_col);
		hockey_open_row_ML2(*ball_row);
	}

	//NUNCA VA A PASAR QUE REBOTE DE MANERA VERTICAL CON UN POSTE DE UNA PORTERIA
	if(*direction == 7){
		if(*ball_row == 0b00000001)
			*direction = 2;
		else
			*ball_row >>= 1;
	}
	else if(*direction == 2){
		if(*ball_row == 0b10000000)
			*direction = 7;
		else
			*ball_row <<= 1;
	}
	else if(*direction == 8){
		if(*matrix == 1){
			if(*ball_col == 0b11111110){
				*ball_col = 0b01111111;
				*matrix = 2;
			}
			else{
				*ball_col >>= 1;
				*ball_col += 128;
			}

			if(*ball_row == 0b00000001){
				*ball_row <<= 1;
				*direction = 3;
			}
			else
				*ball_row >>= 1;
		}
		else if(*matrix == 2){
			if(*ball_col == 0b11111110){
				if(*ball_row == 0b00000001){
					*ball_col <<= 1;
					*ball_col += 1;
					*direction = 1;
				}
				else if(*ball_row == 0b00010000 || *ball_row == 0b00001000){
					*goal = 1;
				}
				else{
					*ball_row >>= 1;
					*ball_col <<= 1;
					*ball_col += 1;
					*direction = 6;
				}
			}
			else{
				if(*ball_row == 0b00000001){
					*ball_row <<= 1;
					*direction = 3;
				}
				else{
					*ball_row >>= 1;
				}
				*ball_col >>= 1;
				*ball_col += 128;
			}
		}
	}
	else if(*direction == 5){
		if(*matrix == 1){
			if(*ball_col == 0b11111110){
				*ball_col = 0b01111111;
				*matrix = 2;
			}
			else{
				*ball_col >>= 1;
				*ball_col += 128;
			}
		}
		else if(*matrix == 2){
			if(*ball_col == 0b11111110){
				if(*ball_row == 0b00010000 || *ball_row == 0b00001000){
					*goal = 1;
				}
				else{
					*ball_col <<= 1;
					*ball_col += 1;
					*direction = 4;
				}
			}
			else{
				*ball_col >>= 1;
				*ball_col += 128;
			}
		}
	}
	else if(*direction == 3){
		if(*matrix == 1){
			if(*ball_col == 0b11111110){
				*ball_col = 0b01111111;
				*matrix = 2;
			}
			else{
				*ball_col >>= 1;
				*ball_col += 128;
			}

			if(*ball_row == 0b10000000){
				*ball_row >>= 1;
				*direction = 8;
			}
			else
				*ball_row <<= 1;
		}
		else if(*matrix == 2){
			if(*ball_col == 0b11111110){
				if(*ball_row == 0b10000000){
					*ball_col <<= 1;
					*ball_col += 1;
					*direction = 6;
				}
				else if(*ball_row == 0b00010000 || *ball_row == 0b00001000){
					*goal = 1;
				}
				else{
					*ball_row <<= 1;
					*ball_col <<= 1;
					*ball_col += 1;
					*direction = 1;
				}
			}
			else{
				if(*ball_row == 0b10000000){
					*ball_row >>= 1;
					*direction = 8;
				}
				else{
					*ball_row <<= 1;
				}
				*ball_col >>= 1;
				*ball_col += 128;
			}
		}
	}
	else if(*direction == 6){
		if(*matrix == 2){
			if(*ball_col == 0b01111111){
				*ball_col = 0b11111110;
				*matrix = 1;
			}
			else{
				*ball_col <<= 1;
				*ball_col += 1;
			}

			if(*ball_row == 0b00000001){
				*ball_row <<= 1;
				*direction = 1;
			}
			else
				*ball_row >>= 1;
		}
		else if(*matrix == 1){
			if(*ball_col == 0b01111111){
				if(*ball_row == 0b00000001){
					*ball_col >>= 1;
					*ball_col += 128;
					*direction = 3;
				}
				else if(*ball_row == 0b00010000 || *ball_row == 0b00001000){
					*goal = 1;
				}
				else{
					*ball_row >>= 1;
					*ball_col >>= 1;
					*ball_col += 128;
					*direction = 8;
				}
			}
			else{
				if(*ball_row == 0b00000001){
					*ball_row <<= 1;
					*direction = 1;
				}
				else{
					*ball_row >>= 1;
				}
				*ball_col <<= 1;
				*ball_col += 1;
			}
		}
	}
	else if(*direction == 4){
		if(*matrix == 2){
			if(*ball_col == 0b01111111){
				*ball_col = 0b11111110;
				*matrix = 1;
			}
			else{
				*ball_col <<= 1;
				*ball_col += 1;
			}
		}
		else if(*matrix == 1){
			if(*ball_col == 0b01111111){
				if(*ball_row == 0b00010000 || *ball_row == 0b00001000){
					*goal = 1;
				}
				else{
					*ball_col >>= 1;
					*ball_col += 128;
					*direction = 5;
				}
			}
			else{
				*ball_col <<= 1;
				*ball_col += 1;
			}
		}
	}
	else if(*direction == 1){
		if(*matrix == 2){
			if(*ball_col == 0b01111111){
				*ball_col = 0b11111110;
				*matrix = 1;
			}
			else{
				*ball_col <<= 1;
				*ball_col += 1;
			}

			if(*ball_row == 0b10000000){
				*ball_row >>= 1;
				*direction = 6;
			}
			else
				*ball_row <<= 1;
		}
		else if(*matrix == 1){
			if(*ball_col == 0b01111111){
				if(*ball_row == 0b10000000){
					*ball_col >>= 1;
					*ball_col += 128;
					*direction = 8;
				}
				else if(*ball_row == 0b00010000 || *ball_row == 0b00001000){
					*goal = 1;
				}
				else{
					*ball_row <<= 1;
					*ball_col >>= 1;
					*ball_col += 128;
					*direction = 3;
				}
			}
			else{
				if(*ball_row == 0b10000000){
					*ball_row >>= 1;
					*direction = 6;
				}
				else{
					*ball_row <<= 1;
				}
				*ball_col <<= 1;
				*ball_col += 1;
			}
		}
	}
}

void hockey_player1(uint8_t player1_col, uint8_t player1_row, uint8_t player2_col, uint8_t player2_row, uint8_t ball_col, uint8_t ball_row, uint8_t direction){
	uint8_t prev_player1_col, prev_player1_row, goal = 0, matrix = 1;

	while(1){
		for(int i = 0; i < 80; i++){
			//SE ABRE COLUMNA PARA GOAL1
			hockey_open_col_ML1(goal1_col);
			//SE ABRE COLUMNA PARA GOAL2
			hockey_open_col_ML2(goal2_col);

			//SE ABREN FILAS PARA GOAL1
			hockey_open_row_ML1(goal1_rows);
			//SE ABREN FILAS PARA GOAL2
			hockey_open_row_ML2(goal2_rows);

			//SE CIERRA COLUMNAS Y FILAS
			hockey_close_col_rows();

			//SE ACTUALIZA LA COLUMNA Y FILA DEL PLAYER1
			if(i == 2){ //ESTO ES PARA QUE EL JOYSTICK NO SEA TAN SENSIBLE
				//(se guardan la prev col y prev row del player1 por si le pega a la ball saber de donde le pega)
				prev_player1_col = player1_col;
				prev_player1_row = player1_row;
				hockey_joystick1(&player1_col, &player1_row);
			}
			//SE ABRE COLUMNA PARA PLAYER1
			hockey_open_col_ML1(player1_col);
			//SE ABRE FILA PARA PLAYER1
			hockey_open_row_ML1(player1_row);

			//SE ACTUALIZA LA COLUMNA Y FILA DEL PLAYER2
			//(no es necesario guardar las prev col y row porque el player1 es porque la ball está en la matriz 1 por lo tanto el player2 nunca le pegará)
			if(i == 2)
				hockey_joystick2(&player2_col, &player2_row);
			//SE ABRE COLUMNA PARA PLAYER2
			hockey_open_col_ML2(player2_col);
			//SE ABRE FILA PARA PLAYER2
			hockey_open_row_ML2(player2_row);

			//SE CIERRA COLUMNAS Y FILAS
			hockey_close_col_rows();


			//SE ACTUALIZA LA COLUMNA Y FILA DE LA BALL
			//SE ABRE COLUMNA PARA BALL
			//SE ABRE FILA PARA BALL

			hockey_open_col_ML1(ball_col);
			hockey_open_row_ML1(ball_row);

			//SE CIERRA COLUMNAS Y FILAS
			hockey_close_col_rows();

			HAL_Delay(1);
		}
		//SE PREGUNTA SI LE PEGO Y SI SI SE CHECA DE QUE LADO Y A QUE DIRECCIÓN IRA LA BALL
		if(player1_col == ball_col && player1_row == ball_row){
			if(prev_player1_col == player1_col && prev_player1_row == player1_row)//ESTO ES POR SI EL PLAYER NO SE MUEVE Y AUN ASI LE PEGA A LA BALL
				bounce_with_player(&direction);
			else
				kick(prev_player1_col, prev_player1_row, ball_col, ball_row, &direction);
		}

		//SE ACTUALIZA LA COLUMNA Y FILA DE LA BALL
		//SE ABRE COLUMNA PARA BALL
		//SE ABRE FILA PARA BALL
		move_ball(&ball_col, &ball_row, &direction, &goal, &matrix);

		//SE CIERRA COLUMNAS Y FILAS
		hockey_close_col_rows();

		if(goal || matrix == 2){
			break;
		}
	}

	if(goal){
		//EMPIEZA ÉL OTRA VEZ, SE SUMA PUNTAJE Y SE REINICIA
		p1 = 1;
		p2 = 0;
		points_player2++;
		hockey_init();
	}
	else{
		hockey_player2(player1_col, player1_row, player2_col, player2_row, ball_col, ball_row, direction);
	}
}

void hockey_player2(uint8_t player1_col, uint8_t player1_row, uint8_t player2_col, uint8_t player2_row, uint8_t ball_col, uint8_t ball_row, uint8_t direction){
	uint8_t prev_player2_col, prev_player2_row, goal = 0, matrix = 2;

	while(1){
		for(int i = 0; i < 80; i++){
			//SE ABRE COLUMNA PARA GOAL1
			hockey_open_col_ML1(goal1_col);
			//SE ABRE COLUMNA PARA GOAL2
			hockey_open_col_ML2(goal2_col);

			//SE ABREN FILAS PARA GOAL1
			hockey_open_row_ML1(goal1_rows);
			//SE ABREN FILAS PARA GOAL2
			hockey_open_row_ML2(goal2_rows);

			//SE CIERRA COLUMNAS Y FILAS
			hockey_close_col_rows();

			//SE ACTUALIZA LA COLUMNA Y FILA DEL PLAYER2
			if(i == 2){ //ESTO ES PARA QUE EL JOYSTICK NO SEA TAN SENSIBLE
				//(se guardan la prev col y prev row del player2 por si le pega a la ball saber de donde le pega)
				prev_player2_col = player2_col;
				prev_player2_row = player2_row;
				hockey_joystick2(&player2_col, &player2_row);
			}
			//SE ABRE COLUMNA PARA PLAYER1
			hockey_open_col_ML2(player2_col);
			//SE ABRE FILA PARA PLAYER1
			hockey_open_row_ML2(player2_row);

			//SE ACTUALIZA LA COLUMNA Y FILA DEL PLAYER1
			//(no es necesario guardar las prev col y row porque el player2 es porque la ball está en la matriz 2 por lo tanto el player1 nunca le pegará)
			if(i == 2)
				hockey_joystick1(&player1_col, &player1_row);
			//SE ABRE COLUMNA PARA PLAYER2
			hockey_open_col_ML1(player1_col);
			//SE ABRE FILA PARA PLAYER2
			hockey_open_row_ML1(player1_row);

			//SE CIERRA COLUMNAS Y FILAS
			hockey_close_col_rows();

			//SE ACTUALIZA LA COLUMNA Y FILA DE LA BALL
			//SE ABRE COLUMNA PARA BALL
			//SE ABRE FILA PARA BALL
			hockey_open_col_ML2(ball_col);
			hockey_open_row_ML2(ball_row);

			//SE CIERRA COLUMNAS Y FILAS
			hockey_close_col_rows();

			HAL_Delay(1);
		}
		//SE PREGUNTA SI LE PEGO Y SI SI SE CHECA DE QUE LADO Y A QUE DIRECCIÓN IRA LA BALL
		if(player2_col == ball_col && player2_row == ball_row){
			if(prev_player2_col == player2_col && prev_player2_row == player2_row)//ESTO ES POR SI EL PLAYER NO SE MUEVE Y AUN ASI LE PEGA A LA BALL
				bounce_with_player(&direction);
			else
				kick(prev_player2_col, prev_player2_row, ball_col, ball_row, &direction);
		}

		//SE ACTUALIZA LA COLUMNA Y FILA DE LA BALL
		//SE ABRE COLUMNA PARA BALL
		//SE ABRE FILA PARA BALL
		move_ball(&ball_col, &ball_row, &direction, &goal, &matrix);

		//SE CIERRA COLUMNAS Y FILAS
		hockey_close_col_rows();

		if(goal || matrix == 1){
			break;
		}
	}

	if(goal){
		//EMPIEZA ÉL OTRA VEZ, SE SUMA PUNTAJE Y SE REINICIA
		p1 = 0;
		p2 = 1;
		points_player1++;
		hockey_init();
	}
	else{
		hockey_player1(player1_col, player1_row, player2_col, player2_row, ball_col, ball_row, direction);
	}
}
//HOCKEY


//HICE 3 MODIFICACIONES: 1) EN LA FUNCIÓN DE 'kick' ASIGNO LA VARIABLE A 'aux' PORQUE SI NO NO LO DETECTA (HACE COSAS RARAS)
//						 2) EN LA FUNCIÓN DE 'hockey_joystick2' LE PUSE QUE 'x' FUERA MAYOR A 3000 PORQUE SI NO A CADA RATO SE IBA PARA ARRIBA
//						 3) EN LA FUNCIÓN DE 'ping_pong_joystick2' TAMBIÉN LE PUSE QUE FUERA MAYOR A 3000 PARA QUE NO SE ME FUERA PARA ARRIBA
