/*
 * ml.h
 *
 *  Created on: Sep 25, 2024
 *      Author: AGpar
 */

#include "stm32f4xx_hal.h"

#define ML1_F5_Pin GPIO_PIN_0
#define ML1_F5_GPIO_Port GPIOC
#define ML1_F4_Pin GPIO_PIN_1
#define ML1_F4_GPIO_Port GPIOC
#define ML1_F6_Pin GPIO_PIN_2
#define ML1_F6_GPIO_Port GPIOC
#define ML1_F7_Pin GPIO_PIN_3
#define ML1_F7_GPIO_Port GPIOC
#define ML1_F0_Pin GPIO_PIN_0
#define ML1_F0_GPIO_Port GPIOA
#define ML1_F1_Pin GPIO_PIN_1
#define ML1_F1_GPIO_Port GPIOA
#define ML1_F2_Pin GPIO_PIN_4
#define ML1_F2_GPIO_Port GPIOA
#define ML2_C6_Pin GPIO_PIN_9
#define ML2_C6_GPIO_Port GPIOA
#define ML2_C7_Pin GPIO_PIN_10
#define ML2_C7_GPIO_Port GPIOA
#define ML2_F2_Pin GPIO_PIN_5
#define ML2_F2_GPIO_Port GPIOC
#define ML1_F3_Pin GPIO_PIN_0
#define ML1_F3_GPIO_Port GPIOB
#define ML2_F7_Pin GPIO_PIN_1
#define ML2_F7_GPIO_Port GPIOB
#define ML2_F6_Pin GPIO_PIN_2
#define ML2_F6_GPIO_Port GPIOB
#define ML1_C3_Pin GPIO_PIN_10
#define ML1_C3_GPIO_Port GPIOB
#define ML2_F5_Pin GPIO_PIN_12
#define ML2_F5_GPIO_Port GPIOB
#define ML2_C2_Pin GPIO_PIN_13
#define ML2_C2_GPIO_Port GPIOB
#define ML2_C1_Pin GPIO_PIN_14
#define ML2_C1_GPIO_Port GPIOB
#define ML2_C0_Pin GPIO_PIN_15
#define ML2_C0_GPIO_Port GPIOB
#define ML2_F1_Pin GPIO_PIN_6
#define ML2_F1_GPIO_Port GPIOC
#define ML2_F0_Pin GPIO_PIN_8
#define ML2_F0_GPIO_Port GPIOC
#define ML2_C3_Pin GPIO_PIN_9
#define ML2_C3_GPIO_Port GPIOC
#define ML1_C2_Pin GPIO_PIN_8
#define ML1_C2_GPIO_Port GPIOA
#define ML2_F4_Pin GPIO_PIN_11
#define ML2_F4_GPIO_Port GPIOA
#define ML2_F3_Pin GPIO_PIN_12
#define ML2_F3_GPIO_Port GPIOA
#define ML1_C4_Pin GPIO_PIN_15
#define ML1_C4_GPIO_Port GPIOA
#define ML1_C0_Pin GPIO_PIN_10
#define ML1_C0_GPIO_Port GPIOC
#define ML1_C6_Pin GPIO_PIN_11
#define ML1_C6_GPIO_Port GPIOC
#define ML1_C1_Pin GPIO_PIN_12
#define ML1_C1_GPIO_Port GPIOC
#define ML1_C7_Pin GPIO_PIN_2
#define ML1_C7_GPIO_Port GPIOD
#define ML1_C5_Pin GPIO_PIN_7
#define ML1_C5_GPIO_Port GPIOB
#define ML2_C4_Pin GPIO_PIN_8
#define ML2_C4_GPIO_Port GPIOB
#define ML2_C5_Pin GPIO_PIN_9
#define ML2_C5_GPIO_Port GPIOB

//PING-PONG
#define racket1_col 0b01111111
#define racket2_col 0b11111110
//PING-PONG

//HOCKEY
#define goal1_col 0b01111111
#define goal1_rows 0b00100100
#define goal2_col 0b11111110
#define goal2_rows 0b00100100
#define close_col 0b11111111
#define close_rows 0b00000000
//HOCKEY

//JOYSTICKS
extern uint32_t Joystick_Values[4]; //VARIABLE(parte1)
//JOYSTICKS

void LED_Matrices_init(void);

void write_0(uint8_t matrix);
void write_1(uint8_t matrix);
void write_2(uint8_t matrix);
void write_3(uint8_t matrix);
void write_4(uint8_t matrix);
void write_5(uint8_t matrix);
void write_6(uint8_t matrix);
void write_7(uint8_t matrix);
void write_8(uint8_t matrix);
void write_9(uint8_t matrix);

void ping_pong_open_col_ML1(uint8_t bits);
void ping_pong_open_row_ML1(uint8_t bits);
void ping_pong_open_col_ML2(uint8_t bits);
void ping_pong_open_row_ML2(uint8_t bits);
void ping_pong_ball_going_down_right_left(uint8_t *ball_row, uint8_t *ball_matrix, uint8_t *ball_col, uint8_t *direction, uint8_t *flag);
void ping_pong_ball_going_up_right_left(uint8_t *ball_row, uint8_t *ball_matrix, uint8_t *ball_col, uint8_t *direction, uint8_t *flag);
void ping_pong_init();
void ping_pong_player1(uint8_t racket1_rows, uint8_t racket2_rows, uint8_t ball_col, uint8_t ball_row, uint8_t direction, uint8_t ball_matrix);
void ping_pong_joystick1(uint8_t *racket1_rows, uint8_t i);
void ping_pong_joystick2(uint8_t *racket2_rows, uint8_t i);
void ping_pong_player2(uint8_t racket1_rows, uint8_t racket2_rows, uint8_t ball_col, uint8_t ball_row, uint8_t direction, uint8_t ball_matrix);
void ping_pong_ball_going_down_left_right(uint8_t *ball_row, uint8_t *ball_matrix, uint8_t *ball_col, uint8_t *direction, uint8_t *flag);
void ping_pong_ball_going_up_left_right(uint8_t *ball_row, uint8_t *ball_matrix, uint8_t *ball_col, uint8_t *direction, uint8_t *flag);


void hockey_open_col_ML1(uint8_t bits);
void hockey_open_row_ML1(uint8_t bits);
void hockey_open_col_ML2(uint8_t bits);
void hockey_open_row_ML2(uint8_t bits);
void hockey_close_col_rows();
void hockey_init();
void hockey_joystick1(uint8_t *player1_col, uint8_t *player1_row);
void hockey_joystick2(uint8_t *player2_col, uint8_t *player2_row);
void kick(uint8_t prev_player1_col, uint8_t prev_player1_row, uint8_t ball_col, uint8_t ball_row, uint8_t *direction);
void bounce_with_player(uint8_t *direction);
void move_ball(uint8_t *ball_col, uint8_t *ball_row, uint8_t *direction, uint8_t *goal, uint8_t *matrix);
void hockey_player1(uint8_t player1_col, uint8_t player1_row, uint8_t player2_col, uint8_t player2_row, uint8_t ball_col, uint8_t ball_row, uint8_t direction);
void hockey_player2(uint8_t player1_col, uint8_t player1_row, uint8_t player2_col, uint8_t player2_row, uint8_t ball_col, uint8_t ball_row, uint8_t direction);
